from os import getcwd, makedirs, remove
from win32com.client import Dispatch
from os.path import abspath, exists
from pythoncom import CoInitialize
from docx2txt import process
from shutil import rmtree
from pathlib import Path

parsed_files = []

def parse_docx(path):
    splitted_text = process(str(path)).replace("\t", "").split("\n")
    new_splitted_text = []
    end = False

    for line in splitted_text:
        if not end:
            if line == "" or "акт" in line.lower():
                continue

            if "нижеподписавшиеся" in line.lower():
                end = True
                continue

            new_splitted_text.append(line)

    parsed_files.append({ "path": str(path), "text": "\n".join(new_splitted_text) })


def parse_dir(target_path, level=0):
    for file in target_path.iterdir():
        if file.is_dir():
            parse_dir(file, level + 1)
        else:
            if file.name.lower().startswith("акт"):
                # If .docx
                if ".docx" in file.name:
                    parse_docx(file)
                # If .doc
                else:
                    path = getcwd() + "\\tmp"
                    new_file = str(abspath(path + "\\" + file.name)).replace(".doc", ".docx")

                    if not exists(path):
                        makedirs(path)

                    # .doc to .docx
                    word = Dispatch("Word.application", CoInitialize())
                    wordDoc = word.Documents.Open(abspath(str(file)), False, False, False)
                    wordDoc.SaveAs2(new_file, FileFormat=16)
                    wordDoc.Close()

                    parse_docx(new_file)


if __name__ == "__main__":
    parse_dir(Path(input("Enter the path to the files: ")))

    if exists("result.txt"):
        remove("result.txt")
    
    if exists("tmp"):
        rmtree("tmp")

    with open("result.txt", "w", encoding="utf-8") as file:
        for result in parsed_files:
            file.write("File: " + result.get("path") + "\n")
            file.write("Result:\n" + result.get("text") + "\n\n")
    
    print("The result of parsing is in the file result.txt")